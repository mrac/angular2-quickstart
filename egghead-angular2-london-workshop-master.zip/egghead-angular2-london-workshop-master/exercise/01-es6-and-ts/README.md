## Game Time

* Write a `BoardGame` and `VideoGame` class in two separate files
* `export`/`import` them into the `main` file
* Create an instance of each and pass a `name` into the constructor
* Invoke a `play` method that `return`s the words
`Playing...` and the `name` together in a template string `${}`
* Use `document.body.innerHtml` and a template string `${}` to
add the two playing messages to the dom.
