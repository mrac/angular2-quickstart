## Filling Out Forms

* Make a component with a `form`
* Use `ControlGroup` and `Control` with
`[ng-form-model]` and `ng-control` so sync your form
to your controller
* Use basic `checkbox`, `color`, and `text` inputs
* Use a `select` with `option` and `*ng-for` to create
multiple opions
*Display the data however you'd like