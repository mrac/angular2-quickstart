import {Component, bootstrap} from "angular2/angular2";

@Component({
    selector: `app`,
    template: `
		<div>
			Hello World
		</div>
	`
})
class App {}

bootstrap(App);