import {Component} from "angular2/angular2";

@Component({
    selector: 'todo-input',
    template: `
        <input type="text">
    `
})
export class TodoInput{}