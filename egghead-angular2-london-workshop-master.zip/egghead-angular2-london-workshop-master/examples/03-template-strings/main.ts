let notification = `
    I have
weird       spacing
        when logged in the console
`;

console.log(notification);


let dom = `
    <h1>I'm a piece of dom</h1>
`;

document.body.innerHTML = dom;