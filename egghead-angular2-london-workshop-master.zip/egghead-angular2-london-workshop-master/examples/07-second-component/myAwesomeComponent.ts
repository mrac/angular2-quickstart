import {Component} from "angular2/angular2";

@Component({
    selector: "my-awesome-component",
    template: `
        <div>This is so incredible!!!</div>
    `
})
export default class MyAwesomeComponent {
}