import {bootstrap} from 'angular2/angular2';
import {HTTP_PROVIDERS} from 'angular2/http';
import httpDemo from './simpleHttpDemo'


bootstrap(httpDemo, [HTTP_PROVIDERS]);
