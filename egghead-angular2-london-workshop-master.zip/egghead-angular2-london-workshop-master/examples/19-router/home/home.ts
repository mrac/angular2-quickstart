import {Component, View} from "angular2/angular2";
@Component({
    selector: 'home',
    template: `
        <style>*{font-weight: bold}</style>
        <div>Home section here</div>
    `
})
export default class Admin {
}
