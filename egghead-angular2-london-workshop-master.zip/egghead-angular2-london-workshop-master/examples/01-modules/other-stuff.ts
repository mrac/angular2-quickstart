export let message = "I'm exported from another file";

